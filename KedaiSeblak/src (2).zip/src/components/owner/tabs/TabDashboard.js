﻿
import React, { useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const WARNA = {
  merah: '#C62828',
  merahTua: '#52141D',
  latar: '#F8F5F2',
  putih: '#FFFFFF',
  teks: '#2C1810',
  abu: '#78665E',
  garis: '#EFE7E2',
  hijau: '#15803D',
  kuning: '#D97706',
};

const formatRupiah = (angka) => {
  return `Rp ${Number(angka || 0).toLocaleString('id-ID')}`;
};

const getStatusStok = (item) => {
  const sisa = Number(item.sisa || 0);
  const minimum = Number(item.minimum || 0);

  if (sisa <= 0) return 'Habis';
  if (sisa <= minimum) return 'Menipis';

  return 'Aman';
};

const getTanggalHariIni = () => {
  return new Date().toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
};

function SummaryCard({
  title,
  value,
  subtitle,
  icon,
  color,
  background,
}) {
  return (
    <View style={styles.summaryCard}>
      <View style={styles.summaryTop}>
        <View style={[styles.iconBox, { backgroundColor: background }]}>
          <Ionicons name={icon} size={21} color={color} />
        </View>
      </View>

      <Text style={styles.summaryTitle}>{title}</Text>
      <Text style={styles.summaryValue}>{value}</Text>
      <Text style={styles.summarySubtitle}>{subtitle}</Text>
    </View>
  );
}

export default function TabDashboard({
  setActiveTab,
  stockItems = [],
  expenses = [],
  transactions = [],
  onNavigateToStockFilter,
}) {
  // =========================================
  // RINGKASAN TRANSAKSI
  // =========================================

  const transaksiHariIni = useMemo(() => {
    const hariIni = new Date().toISOString().slice(0, 10);

    return transactions.filter((item) => {
      const status = String(item.status || '').toLowerCase();

      const tanggal = item.tanggalISO
        || item.createdAt?.slice?.(0, 10)
        || '';

      const selesai = [
        'lunas',
        'selesai',
        'paid',
        'completed',
      ].includes(status);

      return selesai && tanggal === hariIni;
    });
  }, [transactions]);

  const totalTransaksi = transaksiHariIni.length;

  const totalOmzet = transaksiHariIni.reduce((total, item) => {
    return total + Number(
      item.total ??
      item.totalHarga ??
      item.grandTotal ??
      item.nominal ??
      0
    );
  }, 0);

  const rataRataTransaksi = totalTransaksi > 0
    ? totalOmzet / totalTransaksi
    : 0;

  // =========================================
  // RINGKASAN PENGELUARAN
  // =========================================

  const totalPengeluaran = useMemo(() => {
    const hariIni = new Date().toISOString().slice(0, 10);
    const tanggalLokal = getTanggalHariIni();

    return expenses
      .filter((item) => {
        return (
          item.tanggalISO === hariIni ||
          item.tanggal === tanggalLokal
        );
      })
      .reduce((total, item) => {
        return total + Number(
          item.nominal ??
          item.total ??
          item.totalBiaya ??
          0
        );
      }, 0);
  }, [expenses]);

  // =========================================
  // RINGKASAN STOK
  // =========================================

  const ringkasanStok = useMemo(() => {
    const items = Array.isArray(stockItems) ? stockItems : [];

    const habis = items.filter(
      (item) => getStatusStok(item) === 'Habis'
    );

    const menipis = items.filter(
      (item) => getStatusStok(item) === 'Menipis'
    );

    const aman = items.filter(
      (item) => getStatusStok(item) === 'Aman'
    );

    return {
      total: items.length,
      habis: habis.length,
      menipis: menipis.length,
      aman: aman.length,
      peringatan: [...habis, ...menipis],
    };
  }, [stockItems]);

  const handleOpenStock = (status) => {
    if (onNavigateToStockFilter) {
      onNavigateToStockFilter(status);
    } else if (setActiveTab) {
      setActiveTab('stok');
    }
  };

  // =========================================
  // TAMPILAN
  // =========================================

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* HEADER DASHBOARD */}
      <View style={styles.header}>
        <View style={styles.headerText}>
          <Text style={styles.pageTitle}>Dashboard Owner</Text>
          <Text style={styles.pageSubtitle}>
            Ringkasan kondisi dan aktivitas Kedai Seblak
          </Text>
        </View>

        <View style={styles.dateBadge}>
          <Ionicons
            name="calendar-outline"
            size={15}
            color={WARNA.merah}
          />
          <Text style={styles.dateText}>
            {getTanggalHariIni()}
          </Text>
        </View>
      </View>

      {/* RINGKASAN UTAMA */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>
          Ringkasan Hari Ini
        </Text>

        <View style={styles.summaryGrid}>
          <SummaryCard
            title="Omzet Hari Ini"
            value={formatRupiah(totalOmzet)}
            subtitle={`${totalTransaksi} transaksi selesai`}
            icon="wallet-outline"
            color="#15803D"
            background="#DCFCE7"
          />

          <SummaryCard
            title="Total Transaksi"
            value={totalTransaksi.toLocaleString('id-ID')}
            subtitle="Transaksi selesai hari ini"
            icon="receipt-outline"
            color="#2563EB"
            background="#DBEAFE"
          />

          <SummaryCard
            title="Rata-rata Transaksi"
            value={formatRupiah(rataRataTransaksi)}
            subtitle="Rata-rata nilai transaksi"
            icon="calculator-outline"
            color="#D97706"
            background="#FEF3C7"
          />

          <SummaryCard
            title="Pengeluaran Hari Ini"
            value={formatRupiah(totalPengeluaran)}
            subtitle="Modal belanja tercatat"
            icon="trending-down-outline"
            color="#DC2626"
            background="#FEE2E2"
          />
        </View>
      </View>

      {/* RINGKASAN INVENTARIS */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>
              Kondisi Persediaan
            </Text>
            <Text style={styles.sectionSubtitle}>
              Ringkasan kondisi stok bahan baku
            </Text>
          </View>

          <TouchableOpacity
            onPress={() => handleOpenStock('Semua')}
            style={styles.linkButton}
          >
            <Text style={styles.linkText}>Lihat Stok</Text>
            <Ionicons
              name="arrow-forward"
              size={15}
              color={WARNA.merah}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.stockSummaryCard}>
          <View style={styles.stockTotal}>
            <Text style={styles.stockTotalNumber}>
              {ringkasanStok.total}
            </Text>
            <Text style={styles.stockTotalLabel}>
              Total jenis bahan
            </Text>
          </View>

          <View style={styles.stockDivider} />

          <View style={styles.stockStatusRow}>
            <TouchableOpacity
              style={styles.stockStatus}
              onPress={() => handleOpenStock('Aman')}
            >
              <View style={[styles.statusDot, { backgroundColor: WARNA.hijau }]} />
              <Text style={styles.statusNumber}>
                {ringkasanStok.aman}
              </Text>
              <Text style={styles.statusLabel}>Aman</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.stockStatus}
              onPress={() => handleOpenStock('Menipis')}
            >
              <View style={[styles.statusDot, { backgroundColor: WARNA.kuning }]} />
              <Text style={styles.statusNumber}>
                {ringkasanStok.menipis}
              </Text>
              <Text style={styles.statusLabel}>Menipis</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.stockStatus}
              onPress={() => handleOpenStock('Habis')}
            >
              <View style={[styles.statusDot, { backgroundColor: WARNA.merah }]} />
              <Text style={styles.statusNumber}>
                {ringkasanStok.habis}
              </Text>
              <Text style={styles.statusLabel}>Habis</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* PERINGATAN STOK */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <View>
            <Text style={styles.sectionTitle}>
              Peringatan Stok
            </Text>
            <Text style={styles.sectionSubtitle}>
              Bahan yang membutuhkan perhatian
            </Text>
          </View>

          <View style={styles.warningCount}>
            <Text style={styles.warningCountText}>
              {ringkasanStok.peringatan.length} bahan
            </Text>
          </View>
        </View>

        <View style={styles.warningCard}>
          {ringkasanStok.peringatan.length === 0 ? (
            <View style={styles.emptyWarning}>
              <Ionicons
                name="checkmark-circle-outline"
                size={34}
                color={WARNA.hijau}
              />
              <Text style={styles.emptyWarningTitle}>
                Semua stok dalam kondisi aman
              </Text>
              <Text style={styles.emptyWarningSubtitle}>
                Belum ada bahan yang perlu segera ditangani.
              </Text>
            </View>
          ) : (
            ringkasanStok.peringatan.slice(0, 5).map((item) => {
              const status = getStatusStok(item);
              const habis = status === 'Habis';

              return (
                <View key={item.id} style={styles.warningItem}>
                  <View style={[
                    styles.warningIcon,
                    {
                      backgroundColor: habis
                        ? '#FEE2E2'
                        : '#FEF3C7',
                    },
                  ]}>
                    <Ionicons
                      name={habis ? 'close-circle-outline' : 'alert-circle-outline'}
                      size={19}
                      color={habis ? WARNA.merah : WARNA.kuning}
                    />
                  </View>

                  <View style={styles.warningInfo}>
                    <Text style={styles.warningName}>
                      {item.nama || item.name || 'Bahan tanpa nama'}
                    </Text>
                    <Text style={styles.warningStock}>
                      Sisa: {item.sisa ?? 0} {item.satuan || ''}
                    </Text>
                  </View>

                  <View style={[
                    styles.warningBadge,
                    {
                      backgroundColor: habis
                        ? '#FEE2E2'
                        : '#FEF3C7',
                    },
                  ]}>
                    <Text style={[
                      styles.warningBadgeText,
                      {
                        color: habis
                          ? WARNA.merah
                          : WARNA.kuning,
                      },
                    ]}>
                      {status}
                    </Text>
                  </View>
                </View>
              );
            })
          )}

          {ringkasanStok.peringatan.length > 0 && (
            <TouchableOpacity
              style={styles.viewAllButton}
              onPress={() => handleOpenStock('Menipis')}
            >
              <Text style={styles.viewAllText}>
                Buka halaman manajemen stok
              </Text>
              <Ionicons
                name="arrow-forward"
                size={15}
                color={WARNA.merah}
              />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* NAVIGASI FITUR */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>
          Akses Menu Owner
        </Text>

        <View style={styles.menuGrid}>
          <TouchableOpacity
            style={styles.menuCard}
            onPress={() => setActiveTab?.('penjualan')}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#DBEAFE' }]}>
              <Ionicons name="bar-chart-outline" size={22} color="#2563EB" />
            </View>
            <Text style={styles.menuTitle}>Penjualan</Text>
            <Text style={styles.menuDescription}>
              Lihat transaksi penjualan
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuCard}
            onPress={() => handleOpenStock('Semua')}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#DCFCE7' }]}>
              <Ionicons name="cube-outline" size={22} color="#15803D" />
            </View>
            <Text style={styles.menuTitle}>Manajemen Stok</Text>
            <Text style={styles.menuDescription}>
              Kelola persediaan bahan
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuCard}
            onPress={() => setActiveTab?.('pengeluaran')}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#FEE2E2' }]}>
              <Ionicons name="wallet-outline" size={22} color={WARNA.merah} />
            </View>
            <Text style={styles.menuTitle}>Pengeluaran</Text>
            <Text style={styles.menuDescription}>
              Catatan modal belanja
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuCard}
            onPress={() => setActiveTab?.('laporan_keuangan')}
          >
            <View style={[styles.menuIcon, { backgroundColor: '#FEF3C7' }]}>
              <Ionicons name="document-text-outline" size={22} color={WARNA.kuning} />
            </View>
            <Text style={styles.menuTitle}>Laporan Keuangan</Text>
            <Text style={styles.menuDescription}>
              Lihat laporan keuangan
            </Text>
          </TouchableOpacity>
        </View>
      </View>

    </ScrollView>
  );
}

// =========================================
// STYLES
// =========================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: WARNA.latar,
  },

  content: {
    padding: 22,
    paddingBottom: 40,
    width: '100%',
    maxWidth: 1200,
    alignSelf: 'center',
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 26,
  },

  headerText: {
    flex: 1,
  },

  pageTitle: {
    fontSize: 25,
    fontWeight: '900',
    color: WARNA.teks,
  },

  pageSubtitle: {
    fontSize: 13,
    color: WARNA.abu,
    marginTop: 5,
  },

  dateBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    backgroundColor: WARNA.putih,
    borderWidth: 1,
    borderColor: WARNA.garis,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
  },

  dateText: {
    fontSize: 12,
    fontWeight: '700',
    color: WARNA.teks,
  },

  section: {
    marginBottom: 25,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 13,
    gap: 10,
  },

  sectionTitle: {
    fontSize: 17,
    fontWeight: '900',
    color: WARNA.teks,
    marginBottom: 4,
  },

  sectionSubtitle: {
    fontSize: 12,
    color: WARNA.abu,
  },

  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 13,
  },

  summaryCard: {
    flexGrow: 1,
    flexBasis: 220,
    backgroundColor: WARNA.putih,
    padding: 17,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: WARNA.garis,
    minHeight: 145,
  },

  summaryTop: {
    marginBottom: 11,
  },

  iconBox: {
    width: 39,
    height: 39,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },

  summaryTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: WARNA.abu,
  },

  summaryValue: {
    fontSize: 20,
    fontWeight: '900',
    color: WARNA.teks,
    marginTop: 5,
  },

  summarySubtitle: {
    fontSize: 11,
    color: '#9A8980',
    marginTop: 5,
  },

  linkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    padding: 7,
  },

  linkText: {
    fontSize: 12,
    color: WARNA.merah,
    fontWeight: '800',
  },

  stockSummaryCard: {
    backgroundColor: WARNA.putih,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: WARNA.garis,
    padding: 19,
  },

  stockTotal: {
    alignItems: 'center',
    marginBottom: 16,
  },

  stockTotalNumber: {
    fontSize: 30,
    fontWeight: '900',
    color: WARNA.teks,
  },

  stockTotalLabel: {
    fontSize: 12,
    color: WARNA.abu,
  },

  stockDivider: {
    height: 1,
    backgroundColor: WARNA.garis,
    marginBottom: 17,
  },

  stockStatusRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },

  stockStatus: {
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
  },

  statusDot: {
    width: 9,
    height: 9,
    borderRadius: 5,
  },

  statusNumber: {
    fontSize: 19,
    fontWeight: '900',
    color: WARNA.teks,
  },

  statusLabel: {
    fontSize: 11,
    color: WARNA.abu,
  },

  warningCount: {
    backgroundColor: '#FEE2E2',
    borderRadius: 20,
    paddingHorizontal: 11,
    paddingVertical: 6,
  },

  warningCountText: {
    fontSize: 11,
    fontWeight: '800',
    color: WARNA.merah,
  },

  warningCard: {
    backgroundColor: WARNA.putih,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: WARNA.garis,
    padding: 16,
  },

  emptyWarning: {
    alignItems: 'center',
    paddingVertical: 23,
  },

  emptyWarningTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: WARNA.teks,
    marginTop: 9,
  },

  emptyWarningSubtitle: {
    fontSize: 11,
    color: WARNA.abu,
    marginTop: 4,
    textAlign: 'center',
  },

  warningItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderBottomColor: '#F4EFEB',
    gap: 10,
  },

  warningIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },

  warningInfo: {
    flex: 1,
  },

  warningName: {
    fontSize: 13,
    fontWeight: '800',
    color: WARNA.teks,
  },

  warningStock: {
    fontSize: 11,
    color: WARNA.abu,
    marginTop: 3,
  },

  warningBadge: {
    paddingHorizontal: 9,
    paddingVertical: 5,
    borderRadius: 7,
  },

  warningBadgeText: {
    fontSize: 10,
    fontWeight: '800',
  },

  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingTop: 15,
  },

  viewAllText: {
    fontSize: 12,
    fontWeight: '800',
    color: WARNA.merah,
  },

  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },

  menuCard: {
    flexGrow: 1,
    flexBasis: 220,
    backgroundColor: WARNA.putih,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: WARNA.garis,
    padding: 15,
  },

  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },

  menuTitle: {
    fontSize: 13,
    fontWeight: '900',
    color: WARNA.teks,
  },

  menuDescription: {
    fontSize: 11,
    color: WARNA.abu,
    marginTop: 4,
  },
});
