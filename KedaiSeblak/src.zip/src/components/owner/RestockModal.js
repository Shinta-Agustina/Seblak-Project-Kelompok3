﻿// src/components/RestockModal.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, TextInput, Alert, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker'; 
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { KATEGORI_BAHAN } from '../data/mockDataOwner';

export default function RestockModal({ visible, onClose, onSaveExpense, onRestockSuccess, currentStockItems }) {
  // State Form
  const [keterangan, setKeterangan] = useState('');
  // Ambil kategori pertama dari data master sebagai default agar tidak kosong
  const [kategori, setKategori] = useState(KATEGORI_BAHAN[0] || ''); 
  const [jumlah, setJumlah] = useState('');
  const [satuan, setSatuan] = useState('kg');
  const [total, setTotal] = useState('');
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);

  const handleSave = () => {
    // Validasi Dasar
    if (!keterangan || !jumlah || !total) {
      Alert.alert('Error', 'Mohon lengkapi Nama Barang, Jumlah, dan Total Biaya');
      return;
    }

    const numJml = parseFloat(jumlah);
    const numTot = parseFloat(total);

    if (isNaN(numJml) || isNaN(numTot) || numJml <= 0 || numTot <= 0) {
      Alert.alert('Error', 'Jumlah dan Total Biaya harus angka valid lebih dari 0');
      return;
    }

    // 1. Buat Objek Expense Baru
    const newExpense = {
      id: `EXP-${Date.now()}`,
      tanggal: date.toISOString().split('T')[0], // Format YYYY-MM-DD
      tanggalStr: date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
      waktu: date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      keterangan: keterangan,
      kategori: kategori,
      jumlah: numJml,
      satuan: satuan,
      total: numTot,
      pic: 'Owner (Simulasi)',
    };

    // 2. Panggil callback layar utama untuk mencatat keuangan
    onSaveExpense(newExpense);

    // 3. LOGIKA OTOMATISASI STOK (INTI DARI FITUR INI)
    // Cek apakah barang yang dibeli ada di daftar stok master
    // Pastikan nama master dan input sama (toLowerCase() digunakan untuk antisipasi typo ketik)
    const bahanIndex = currentStockItems.findIndex(item => item.nama.toLowerCase() === keterangan.trim().toLowerCase());

    let msgRestock = '\n(Hanya tercatat di Keuangan)';

    if (bahanIndex !== -1) {
        const bahanLama = currentStockItems[bahanIndex];
        
        // Pastikan satuan sama (ini asumsi sederhana, di real app perlu konversi kg ke gr)
        if(bahanLama.satuan === satuan) {
             const stokBaru = bahanLama.sisa + numJml;
             // Pastikan data master awal adalah angka, bukan string
             const modalLamaNum = parseFloat(bahanLama.modalTertanam) || 0;
             const modalBaru = modalLamaNum + numTot;
             const hargaRataBaru = stokBaru > 0 ? modalBaru / stokBaru : 0;

             // Panggil callback untuk update state stok di layar utama
             onRestockSuccess(bahanLama.id, stokBaru, modalBaru, hargaRataBaru);
             msgRestock = `\n(Stok ${bahanLama.nama} berhasil diupdate menjadi ${stokBaru} ${satuan})`;
        } else {
             msgRestock = `\n(Satuan tidak sama: Input ${satuan}, Master ${bahanLama.satuan}. Stok tidak otomatis terupdate. Harap sesuaikan manual)`;
        }
    } else {
         // Item belum ada di stok master, hanya dicatat sebagai pengeluaran biasa
         msgRestock = '\n(Item belum terdaftar di Stok Bahan. Silakan tambahkan di menu Stok jika ingin dikelola)';
    }

    Alert.alert('Sukses', `Pengeluaran Modal Berhasil Dicatat!${msgRestock}`, [{ text: 'OK', onPress: onClose }]);

    // Reset Form
    setKeterangan('');
    setJumlah('');
    setTotal('');
  };

  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setDate(selectedDate);
    }
  };

  return (
    <Modal animationType="slide" transparent={true} visible={visible} onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.headerRow}>
            <Text style={styles.title}>Input Belanja / Restock</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Ionicons name="close" size={24} color="#78665E" />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Input Tanggal */}
            <Text style={styles.label}>Tanggal Transaksi</Text>
            <TouchableOpacity style={styles.dateInput} onPress={() => setShowDatePicker(true)}>
              <Ionicons name="calendar-outline" size={20} color="#8D7B70" style={{marginRight: 10}}/>
              <Text style={styles.dateText}>{date.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</Text>
            </TouchableOpacity>
            {showDatePicker && (<DateTimePicker value={date} mode="default" display="default" onChange={onDateChange} />)}

            {/* Input Keterangan / Nama Barang */}
            <Text style={styles.label}>Nama Barang (Sama dengan di Stok)</Text>
            <TextInput style={styles.input} placeholder="Cth: Kerupuk Bawang (Mawar)" value={keterangan} onChangeText={setKeterangan} />

            {/* Input Kategori */}
            <Text style={styles.label}>Kategori</Text>
            <View style={styles.pickerWrapper}>
                {/* PERBAIKAN TYPO DI SINI: gunakan onValueChange */}
                <Picker 
                    selectedValue={kategori} 
                    onValueChange={(itemValue) => setKategori(itemValue)}
                >
                    {KATEGORI_BAHAN.map(kat => <Picker.Item key={kat} label={kat} value={kat} />)}
                </Picker>
            </View>
            
            {/* Input Jumlah & Satuan */}
            <Text style={styles.label}>Jumlah & Satuan</Text>
            <View style={styles.row}>
              <TextInput style={[styles.input, {flex: 2, marginRight: 10}]} placeholder="Cth: 5" keyboardType="numeric" value={jumlah} onChangeText={setJumlah} />
              <View style={[styles.pickerWrapper, {flex: 1}]}>
                 {/* PERBAIKAN TYPO DI SINI: gunakan onValueChange */}
                <Picker 
                    selectedValue={satuan} 
                    onValueChange={(itemValue) => setSatuan(itemValue)}
                >
                  <Picker.Item label="kg" value="kg" />
                  <Picker.Item label="pack" value="pack" />
                  <Picker.Item label="butir" value="butir" />
                  <Picker.Item label="liter" value="liter" />
                </Picker>
              </View>
            </View>

            {/* Input Total */}
            <Text style={styles.label}>Total Biaya (Rp)</Text>
            <TextInput style={styles.input} placeholder="Cth: 130000" keyboardType="numeric" value={total} onChangeText={setTotal} />

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
              <Text style={styles.saveBtnText}>Simpan & Update Stok Otomatis</Text>
            </TouchableOpacity>
            
            <View style={{height: 50}}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
    modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
    modalContent: { backgroundColor: '#F8F5F2', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, maxHeight: '90%' },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    title: { fontSize: 18, fontWeight: '900', color: '#2C1810' },
    closeBtn: { padding: 5 },
    label: { fontSize: 12, color: '#78665E', marginBottom: 6, fontWeight: '600' },
    input: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#EFE7E2', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, marginBottom: 16, color: '#2C1810' },
    row: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
    pickerWrapper: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#EFE7E2', borderRadius: 10, height: 50, justifyContent: 'center', marginBottom: 16 },
    saveBtn: { backgroundColor: '#C62828', paddingVertical: 14, borderRadius: 12, alignItems: 'center', marginTop: 20, elevation: 3 },
    saveBtnText: { color: '#FFFFFF', fontWeight: '800', fontSize: 14 },
    dateInput: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#EFE7E2', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 16, flexDirection: 'row', alignItems: 'center' },
    dateText: { fontSize: 14, color: '#2C1810' },
});