// src/screens/Owner/DashboardScreen.js
import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
// IMPORT SEMUA DATA DUMMY & LOGIKA KALKULASI
import { 
    INITIAL_STOCK_ITEMS, 
    INITIAL_EXPENSES, 
    DUMMY_SALES_ALL_OCT_2026 
} from '../../data/mockDataGlobal';

// Helper Format Rupiah
const formatRupiah = (angka) => {
    if (angka === null || angka === undefined) return 'Rp 0';
    return `Rp ${angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
};

export default function DashboardScreen({ navigation }) {
    // --- LOGIKA PENGAMBILAN DATA DARI MODUL LAIN (Disimulasikan di sini) ---
    
    // Asumsi hari ini adalah tanggal 16 Oktober 2026 (Sesuai data dummy kita)
    const DEMO_TODAY = '2026-10-16';

    const dashboardData = useMemo(() => {
        // 1. Data Omset (Dari LaporanScreen / Data Kasir)
        const salesToday = DUMMY_SALES_ALL_OCT_2026.filter(s => s.tanggal === DEMO_TODAY);
        const totalOmset = salesToday.reduce((sum, s) => sum + s.total, 0);

        // 2. Data Pengeluaran & HPP (Dari PengeluaranScreen)
        const expensesToday = INITIAL_EXPENSES.filter(e => e.tanggal === DEMO_TODAY);
        
        const totalHpp = expensesToday
            .filter(e => e.kategori !== 'Operasional')
            .reduce((sum, e) => sum + e.total, 0);
            
        const totalOperasional = expensesToday
            .filter(e => e.kategori === 'Operasional')
            .reduce((sum, e) => sum + e.total, 0);

        // 3. Kalkulasi Laba Rugi Hari Ini
        const labaKotor = totalOmset - totalHpp;
        const labaBersih = labaKotor - totalOperasional;

        // 4. Data Stok (Dari TabStok)
        const bahanTotal = INITIAL_STOCK_ITEMS.length;
        const bahanHabis = INITIAL_STOCK_ITEMS.filter(item => item.sisa <= 0).length;
        const bahanMenipis = INITIAL_STOCK_ITEMS.filter(item => item.sisa > 0 && item.sisa <= item.minimum).length;
        
        // Daftar Bahan yang Habis (Untuk Peringatan Dini)
        const criticalStockList = INITIAL_STOCK_ITEMS.filter(item => item.sisa <= 0);

        return {
            totalOmset,
            labaBersih,
            bahanHabis,
            bahanMenipis,
            criticalStockList
        };

    }, [INITIAL_STOCK_ITEMS, INITIAL_EXPENSES]); // Recalculate jika data berubah


    // --- KOMPONEN KARTU STATISTIK ---
    const StatCard = ({ title, value, icon, color, onPress }) => (
        <TouchableOpacity style={[styles.statCard, {borderLeftColor: color}]} onPress={onPress}>
            <View style={styles.cardTop}>
                <Text style={styles.statTitle}>{title}</Text>
                <View style={[styles.iconWraper, {backgroundColor: `${color}20`}]}>
                     <Ionicons name={icon} size={18} color={color} />
                </View>
            </View>
            <Text style={styles.statValue}>{value}</Text>
            <Text style={styles.cardSub}>{title === 'Omset Hari Ini' || title === 'Laba Bersih' ? 'Dibanding kemarin (Simulasi)' : 'Total Data Master'}</Text>
        </TouchableOpacity>
    );

    // --- KOMPONEN ITEM PERINGATAN STOK ---
    const renderCriticalItem = ({ item }) => (
        <View style={styles.criticalItem}>
            <Ionicons name="alert-circle" size={16} color="#C62828" />
            <Text style={styles.criticalText}>{item.nama} Habis!</Text>
            <TouchableOpacity style={styles.restockLink} onPress={() => navigation.navigate('StokOwner')}>
                <Text style={styles.restockLinkText}>Restock Sekarang</Text>
            </TouchableOpacity>
        </View>
    );

    // --- TAMPILAN UI DASHBOARD ---
    return (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
            {/* Header Dashboard */}
            <View style={styles.headerSection}>
                <View>
                    <Text style={styles.greeting}>Selamat Pagi, Owner!</Text>
                    <Text style={styles.dateHeader}>Rabu, 16 Oktober 2026 (Simulasi Data Skripsi)</Text>
                </View>
                <TouchableOpacity style={styles.profileBtn}>
                    <Ionicons name="notifications-outline" size={24} color="#2C1810" />
                </TouchableOpacity>
            </View>

            {/* Bagian Alert Stok Kritis (Penting bagi Owner) */}
            {dashboardData.criticalStockList.length > 0 && (
                <View style={styles.alertSection}>
                    <Text style={styles.alertTitle}>⚠️ PERINGATAN STOK BAHAN</Text>
                    <FlatList
                        data={dashboardData.criticalStockList}
                        renderItem={renderCriticalItem}
                        keyExtractor={item => item.id}
                        scrollEnabled={false} // Agar tidak konflik scroll dengan parent ScrollView
                    />
                </View>
            )}

            {/* Bagian Statistik Utama (Grid 2x2) */}
            <View style={styles.statsContainer}>
                <View style={styles.rowStats}>
                    <StatCard 
                        title="Omset Hari Ini" 
                        value={formatRupiah(dashboardData.totalOmset)} 
                        icon="cash-outline" 
                        color="#168653" 
                        onPress={() => navigation.navigate('LaporanOwner')} // Navigasi ke detail
                    />
                    <StatCard 
                        title="Laba Bersih" 
                        value={formatRupiah(dashboardData.labaBersih)} 
                        icon="trending-up-outline" 
                        color="#C62828" 
                        onPress={() => navigation.navigate('LaporanOwner')}
                    />
                </View>
                <View style={styles.rowStats}>
                    <StatCard 
                        title="Bahan Habis" 
                        value={`${dashboardData.bahanHabis} Item`} 
                        icon="alert-triangle-outline" 
                        color="#D97706" 
                        onPress={() => navigation.navigate('StokOwner', {tab: 'habis'})} // Navigasi ke tab spesifik
                    />
                    <StatCard 
                        title="Bahan Menipis" 
                        value={`${dashboardData.bahanMenipis} Item`} 
                        icon="layers-outline" 
                        color="#78665E" 
                        onPress={() => navigation.navigate('StokOwner', {tab: 'menipis'})}
                    />
                </View>
            </View>

            {/* Bagian Tombol Akses Cepat */}
            <View style={styles.quickAccessSection}>
                <Text style={styles.sectionLabel}>Akses Cepat</Text>
                <View style={styles.quickBtnRow}>
                    <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('PengeluaranOwner')}>
                        <Ionicons name="cart-outline" size={24} color="#C62828" />
                        <Text style={styles.quickBtnText}>Input{"\n"}Belanja</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('LaporanOwner')}>
                        <Ionicons name="document-text-outline" size={24} color="#C62828" />
                        <Text style={styles.quickBtnText}>Cek{"\n"}Laporan</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('KasirOwner')}>
                        <Ionicons name="people-outline" size={24} color="#C62828" />
                        <Text style={styles.quickBtnText}>Kelola{"\n"}Kasir</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.quickBtn} onPress={() => Alert.alert('Info', 'Fitur grafik dalam pengembangan')}>
                        <Ionicons name="bar-chart-outline" size={24} color="#C62828" />
                        <Text style={styles.quickBtnText}>Grafik{"\n"}Penjualan</Text>
                    </TouchableOpacity>
                </View>
            </View>

            {/* Footer Space */}
            <View style={{ height: 30 }} />

        </ScrollView>
    );
}

// Styling Dashboard
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8F5F2' },
    headerSection: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 20, backgroundColor: '#FFFFFF', borderBottomWidth: 1, borderColor: '#EFE7E2' },
    greeting: { fontSize: 18, fontWeight: '900', color: '#2C1810' },
    dateHeader: { fontSize: 10, color: '#78665E', marginTop: 2 },
    profileBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#F8F5F2', justifyContent: 'center', alignItems: 'center' },

    // Alert Section
    alertSection: { backgroundColor: '#FFF1F2', margin: 16, marginBottom: 0, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: '#FECACA' },
    alertTitle: { fontSize: 11, fontWeight: '800', color: '#B91C1C', marginBottom: 8, letterSpacing: 0.5 },
    criticalItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF', padding: 8, borderRadius: 8, marginBottom: 6, gap: 6, borderWidth: 1, borderColor: '#FEE2E2' },
    criticalText: { fontSize: 11, color: '#C62828', fontWeight: '700', flex: 1 },
    restockLink: { backgroundColor: '#DC2626', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 6 },
    restockLinkText: { color: '#FFFFFF', fontSize: 9, fontWeight: '700' },

    // Stats Section
    statsContainer: { padding: 16, gap: 16 },
    rowStats: { flexDirection: 'row', gap: 16 },
    statCard: { backgroundColor: '#FFFFFF', flex: 1, padding: 16, borderRadius: 16, borderWidth: 1, borderColor: '#EFE7E2', borderLeftWidth: 4, elevation: 2 },
    cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    statTitle: { fontSize: 11, color: '#78665E', fontWeight: '600' },
    iconWraper: { width: 30, height: 30, borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
    statValue: { fontSize: 18, fontWeight: '900', color: '#2C1810', marginVertical: 8 },
    cardSub: { fontSize: 9, color: '#A89A92', fontStyle: 'italic' },

    // Quick Access Section
    quickAccessSection: { padding: 16 },
    sectionLabel: { fontSize: 12, fontWeight: '800', color: '#78665E', marginBottom: 10 },
    quickBtnRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 10 },
    quickBtn: { backgroundColor: '#FFFFFF', flex: 1, paddingVertical: 16, paddingHorizontal: 10, borderRadius: 12, alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, borderColor: '#EFE7E2', elevation: 1 },
    quickBtnText: { fontSize: 10, fontWeight: '700', color: '#2C1810', textAlign: 'center' },
});