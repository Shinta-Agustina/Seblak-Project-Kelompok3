// src/screens/Owner/ManajemenKasirScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
// Import data dummy global
import { MOCK_KASIR, MOCK_SHIFT_MONITORING } from '../../data/mockDataGlobal';

// Helper Format Rupiah
const formatRupiah = (angka) => {
    if (angka === null || angka === undefined) return 'Rp 0';
    return `Rp ${angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
};

export default function ManajemenKasirScreen() {
    // State Lokal untuk Mock Data (Di real app ini dari API)
    const [kasirList, setKasirList] = useState(MOCK_KASIR);
    const [shiftData, setShiftData] = useState(MOCK_SHIFT_MONITORING);
    const [modalVisible, setModalVisible] = useState(false);
    const [newNama, setNewNama] = useState('');
    const [newUsername, setNewUsername] = useState('');

    // --- Logika Tambah Kasir (Simulasi) ---
    const handleAddKasir = () => {
        if(!newNama || !newUsername) {
            Alert.alert('Error', 'Nama dan Username wajib diisi');
            return;
        }
        const newId = `KSR0${kasirList.length + 1}`;
        const newKasir = {
            id: newId,
            nama: newNama,
            username: newUsername,
            status: 'aktif',
            pin: '1234' // Default PIN
        };
        setKasirList(prev => [...prev, newKasir]);
        setNewNama('');
        setNewUsername('');
        setModalVisible(false);
        Alert.alert('Sukses', 'Kasir baru berhasil ditambahkan.');
    };

    // --- Komponen Card Monitoring Shift (Poin Skripsi) ---
    const renderShiftMonitor = ({ item }) => {
        const isBuka = item.statusShift === 'BUKA';
        const selisih = item.selisihFisik || 0;

        return (
            <View style={styles.shiftCard}>
                {/* Header Card */}
                <View style={styles.cardHeader}>
                    <View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
                        <Ionicons name="person-circle" size={36} color="#52141D" />
                        <View>
                            <Text style={styles.kasirName}>{item.namaKasir}</Text>
                            <Text style={styles.kasirId}>{item.kasirId}</Text>
                        </View>
                    </View>
                    <View style={[styles.statusBadge, { backgroundColor: isBuka ? '#DCFCE7' : '#F3F4F6' }]}>
                        <Ionicons name={isBuka ? 'lock-open-outline' : 'lock-closed-outline'} size={12} color={isBuka? '#168653' : '#6B7280'} />
                        <Text style={[styles.statusText, { color: isBuka? '#168653' : '#6B7280' }]}>{item.statusShift}</Text>
                    </View>
                </View>

                {/* Body Card: Data Keuangan */}
                <View style={styles.cardBody}>
                    <div style={styles.rowBetween}>
                        <Text style={styles.dataLabel}>Modal Awal</Text>
                        <Text style={styles.dataValue}>{formatRupiah(item.modalAwal)}</Text>
                    </div>
                    <div style={styles.rowBetween}>
                        <Text style={styles.dataLabel}>Omset di Laci (Sistem)</Text>
                        <Text style={[styles.dataValue, {color: '#C62828', fontWeight: '700'}]}>{formatRupiah(item.omsetKotorSementara)}</Text>
                    </div>
                    <div style={styles.rowBetween}>
                        <Text style={styles.dataLabel}>Total Transaksi</Text>
                        <Text style={styles.dataValue}>{item.totalTransaksi} Struk</Text>
                    </div>
                    
                    <View style={styles.divider} />

                    <div style={styles.rowBetween}>
                        <Text style={[styles.dataLabel, {fontWeight: '800', color: '#2C1810'}]}>Estimasi Fisik (Total)</Text>
                        <Text style={[styles.totalFisik, { color: selisih < 0 ? '#C62828' : '#2C1810' }]}>
                            {formatRupiah(item.estimasiUangFisik)}
                        </Text>
                    </div>
                    
                    {/* Notifikasi Selisih (Jika Tutup Shift) */}
                    {!isBuka && selisih !== 0 && (
                        <View style={[styles.selisihBox, {backgroundColor: selisih < 0 ? '#FEF2F2' : '#ECFDF5'}]}>
                            <Ionicons name={selisih < 0 ? 'alert-circle' : 'checkmark-circle'} size={14} color={selisih < 0 ? '#B91C1C' : '#059669'} />
                            <Text style={[styles.selisihText, {color: selisih < 0 ? '#B91C1C' : '#059669'}]}>
                                Selisih Fisik Saat Tutup: {formatRupiah(selisih)} ({selisih < 0 ? 'TEKOR' : 'LEBIH'})
                            </Text>
                        </View>
                    )}
                    {!isBuka && selisih === 0 && item.statusShift === 'TUTUP' && (
                         <View style={[styles.selisihBox, {backgroundColor: '#F3F4F6'}]}>
                            <Ionicons name='checkmark-circle' size={14} color='#6B7280' />
                            <Text style={[styles.selisihText, {color: '#6B7280'}]}>Shift ditutup (Belum input fisik/Nihil)</Text>
                        </View>
                    )}
                </View>

                {/* Footer Card */}
                <View style={styles.cardFooter}>
                    <Text style={styles.shiftTime}>
                        Shift Mulai: {new Date(item.waktuMulai).toLocaleDateString('id-ID')} {new Date(item.waktuMulai).toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'})}
                    </Text>
                </View>
            </View>
        );
    };

    // --- Tampilan Utama ---
    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <View>
                    <Text style={styles.pageTitle}>Manajemen Kasir</Text>
                    <Text style={styles.pageSubtitle}>Monitoring Kinerja & Kontrol Laci Kas</Text>
                </View>
                <TouchableOpacity style={styles.addBtn} onPress={() => setModalVisible(true)}>
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addBtnText}>Tambah Kasir</Text>
                </TouchableOpacity>
            </View>

            {/* Judul Bagian */}
            <Text style={styles.sectionHeader}>Monitoring Shift Laci Kasir (Real-time)</Text>

            {/* Daftar Monitoring Shift (FlatList) */}
            <FlatList
                data={shiftData}
                renderItem={renderShiftMonitor}
                keyExtractor={item => item.kasirId}
                contentContainerStyle={{ paddingBottom: 20 }}
                ListEmptyComponent={<Text style={{textAlign: 'center', marginTop: 20, color: '#78665E'}}>Belum ada data shift.</Text>}
            />

            {/* Modal Tambah Kasir */}
            <Modal animationType="slide" transparent={true} visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <Text style={styles.modalTitle}>Tambah Akun Kasir Baru</Text>
                        <TextInput style={styles.input} placeholder="Nama Lengkap" value={newNama} onChangeText={setNewNama} />
                        <TextInput style={styles.input} placeholder="Username (untuk login)" value={newUsername} onChangeText={setNewUsername} autoCapitalize="none" />
                        <Text style={{fontSize: 10, color: '#78665E', marginBottom: 20, fontStyle: 'italic'}}>Password default akan diset oleh sistem.</Text>
                        
                        <View style={styles.modalBtnRow}>
                            <TouchableOpacity style={[styles.modalBtn, styles.btnCancel]} onPress={() => setModalVisible(false)}>
                                <Text style={styles.btnCancelText}>Batal</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={[styles.modalBtn, styles.btnSave]} onPress={handleAddKasir}>
                                <Text style={styles.btnSaveText}>Simpan Kasir</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

// Styling (Gunakan style consistent seperti modul sebelumnya)
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8F5F2', padding: 16 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
    pageTitle: { fontSize: 20, fontWeight: '900', color: '#2C1810', letterSpacing: -0.3 },
    pageSubtitle: { fontSize: 11, color: '#78665E', marginTop: 2 },
    addBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#C62828', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 10, elevation: 2 },
    addBtnText: { color: '#FFFFFF', fontWeight: '700', fontSize: 11 },
    sectionHeader: { fontSize: 14, fontWeight: '800', color: '#2C1810', marginBottom: 12, marginTop: 10 },
    
    // Shift Card Styles
    shiftCard: { backgroundColor: '#FFFFFF', borderRadius: 16, marginBottom: 16, borderWidth: 1, borderColor: '#EFE7E2', elevation: 3 },
    cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderColor: '#EFE7E2' },
    kasirName: { fontSize: 15, fontWeight: '800', color: '#2C1810' },
    kasirId: { fontSize: 10, color: '#78665E' },
    statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 4, paddingHorizontal: 8, borderRadius: 12 },
    statusText: { fontSize: 10, fontWeight: '700' },
    
    cardBody: { padding: 16, gap: 8 },
    rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    dataLabel: { fontSize: 11, color: '#78665E' },
    dataValue: { fontSize: 11, color: '#2C1810', fontWeight: '600' },
    divider: { height: 1, backgroundColor: '#F8F5F2', marginVertical: 4 },
    totalFisik: { fontSize: 14, fontWeight: '900' },
    selisihBox: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 8, borderRadius: 8, marginTop: 8 },
    selisihText: { fontSize: 10, fontWeight: '700' },

    cardFooter: { backgroundColor: '#F8F5F2', padding: 8, paddingHorizontal: 16, borderBottomLeftRadius: 16, borderBottomRightRadius: 16 },
    shiftTime: { fontSize: 9, color: '#A89A92', fontStyle: 'italic' },

    // Modal Styles
    modalOverlay: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
    modalContent: { backgroundColor: '#FFFFFF', width: '90%', padding: 24, borderRadius: 20, elevation: 5 },
    modalTitle: { fontSize: 16, fontWeight: '800', color: '#2C1810', marginBottom: 20 },
    input: { backgroundColor: '#F8F5F2', borderWidth: 1, borderColor: '#EFE7E2', borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 12, marginBottom: 12, color: '#2C1810' },
    modalBtnRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
    modalBtn: { flex: 1, paddingVertical: 12, borderRadius: 10, alignItems: 'center' },
    btnCancel: { backgroundColor: '#F3F4F6', marginRight: 10 },
    btnCancelText: { color: '#6B7280', fontWeight: '700', fontSize: 12 },
    btnSave: { backgroundColor: '#C62828' },
    btnSaveText: { color: '#FFFFFF', fontWeight: '700', fontSize: 12 },
});